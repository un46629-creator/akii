# Course API – Express.js, Modular MVC

REST API with Authentication, Category CRUD and Course CRUD (Express + MongoDB + JWT).

## Folder structure

```
course-api/
├── server.js
├── .env.example
└── src/
    ├── app.js
    ├── config/db.js
    ├── middleware/   (auth, validate, notFound, errorHandler)
    ├── utils/ApiError.js
    └── modules/
        ├── auth/       (model, controller, routes)
        ├── category/   (model, controller, routes)
        └── course/     (model, controller, routes)
```

## Setup

1. Install Node.js and MongoDB (or use a free MongoDB Atlas URI).
2. `npm install`
3. Copy `.env.example` to `.env` and set `MONGO_URI` and `JWT_SECRET`.
4. `npm run dev` (or `npm start`). Server runs on http://localhost:5000

## Endpoints

| Method | URL | Auth | Description |
|---|---|---|---|
| POST | /api/auth/register | No | Register (name, email, password) |
| POST | /api/auth/login | No | Login, returns JWT token |
| GET | /api/auth/me | Yes | Current user |
| POST | /api/categories | Yes | Create category (name, description) |
| GET | /api/categories | Yes | List categories |
| GET | /api/categories/:id | Yes | Get one |
| PUT | /api/categories/:id | Yes | Update |
| DELETE | /api/categories/:id | Yes | Delete |
| POST | /api/courses | Yes | Create (title, description, price, category, duration) |
| GET | /api/courses | Yes | List (optional `?category=<id>`) |
| GET | /api/courses/:id | Yes | Get one |
| PUT | /api/courses/:id | Yes | Update |
| DELETE | /api/courses/:id | Yes | Delete |

Protected routes need the header: `Authorization: Bearer <token>`

## Status codes used

200 OK, 201 Created, 400 Bad Request (validation), 401 Unauthorized, 404 Not Found, 409 Conflict (duplicate).
