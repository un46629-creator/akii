const mongoose = require('mongoose');
const ApiError = require('../utils/ApiError');

// Returns 400 if any required field is missing/empty
exports.requireFields = (fields) => (req, res, next) => {
  const missing = fields.filter((f) => {
    const v = req.body[f];
    return v === undefined || v === null || String(v).trim() === '';
  });
  if (missing.length) {
    return next(new ApiError(400, 'Validation failed: required field(s) missing', missing.map((f) => `${f} is required`)));
  }
  next();
};

// Returns 404 if :id is not a valid MongoDB ObjectId
exports.validateObjectId = (req, res, next) => {
  if (!mongoose.Types.ObjectId.isValid(req.params.id)) {
    return next(new ApiError(404, 'Resource not found (invalid id)'));
  }
  next();
};
