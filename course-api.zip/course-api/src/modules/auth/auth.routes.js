const router = require('express').Router();
const { register, login, me } = require('./auth.controller');
const { requireFields } = require('../../middleware/validate');
const protect = require('../../middleware/auth');

router.post('/register', requireFields(['name', 'email', 'password']), register);
router.post('/login', requireFields(['email', 'password']), login);
router.get('/me', protect, me);

module.exports = router;
