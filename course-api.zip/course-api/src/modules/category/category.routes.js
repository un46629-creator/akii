const router = require('express').Router();
const c = require('./category.controller');
const protect = require('../../middleware/auth');
const { requireFields, validateObjectId } = require('../../middleware/validate');

router.use(protect); // all category routes need a JWT

router.route('/').get(c.getCategories).post(requireFields(['name']), c.createCategory);
router
  .route('/:id')
  .get(validateObjectId, c.getCategory)
  .put(validateObjectId, c.updateCategory)
  .delete(validateObjectId, c.deleteCategory);

module.exports = router;
