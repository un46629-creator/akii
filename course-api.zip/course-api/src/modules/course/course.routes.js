const router = require('express').Router();
const c = require('./course.controller');
const protect = require('../../middleware/auth');
const { requireFields, validateObjectId } = require('../../middleware/validate');

router.use(protect); // all course routes need a JWT

router
  .route('/')
  .get(c.getCourses)
  .post(requireFields(['title', 'description', 'price', 'category']), c.createCourse);
router
  .route('/:id')
  .get(validateObjectId, c.getCourse)
  .put(validateObjectId, c.updateCourse)
  .delete(validateObjectId, c.deleteCourse);

module.exports = router;
