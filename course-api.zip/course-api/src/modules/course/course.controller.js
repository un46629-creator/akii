const mongoose = require('mongoose');
const Course = require('./course.model');
const Category = require('../category/category.model');
const ApiError = require('../../utils/ApiError');

const ensureCategory = async (id) => {
  if (!mongoose.Types.ObjectId.isValid(id)) throw new ApiError(400, 'Invalid category id');
  const exists = await Category.exists({ _id: id });
  if (!exists) throw new ApiError(404, 'Category not found');
};

exports.createCourse = async (req, res, next) => {
  try {
    const { title, description, price, duration, category } = req.body;
    await ensureCategory(category);
    const course = await Course.create({ title, description, price, duration, category, createdBy: req.user._id });
    res.status(201).json({ success: true, message: 'Course created', data: course });
  } catch (err) {
    next(err);
  }
};

exports.getCourses = async (req, res, next) => {
  try {
    const filter = req.query.category ? { category: req.query.category } : {};
    const courses = await Course.find(filter).populate('category', 'name').sort({ createdAt: -1 });
    res.status(200).json({ success: true, count: courses.length, data: courses });
  } catch (err) {
    next(err);
  }
};

exports.getCourse = async (req, res, next) => {
  try {
    const course = await Course.findById(req.params.id).populate('category', 'name');
    if (!course) throw new ApiError(404, 'Course not found');
    res.status(200).json({ success: true, data: course });
  } catch (err) {
    next(err);
  }
};

exports.updateCourse = async (req, res, next) => {
  try {
    if (req.body.category) await ensureCategory(req.body.category);
    const course = await Course.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    if (!course) throw new ApiError(404, 'Course not found');
    res.status(200).json({ success: true, message: 'Course updated', data: course });
  } catch (err) {
    next(err);
  }
};

exports.deleteCourse = async (req, res, next) => {
  try {
    const course = await Course.findByIdAndDelete(req.params.id);
    if (!course) throw new ApiError(404, 'Course not found');
    res.status(200).json({ success: true, message: 'Course deleted' });
  } catch (err) {
    next(err);
  }
};
